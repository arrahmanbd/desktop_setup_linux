# VLC-Arc-Dark
  Arc Dark skin for [VLC](http://www.videolan.org/vlc/)

![Screenshot](preview.png)
# Install
```
git clone https://github.com/varlesh/VLC-Arc-Dark.git ;\
cd VLC-Arc-Dark ;\
sudo make install
```
## Arch Linux Installation

```
yaourt -S vlc-arc-dark-git
```
# License
GPL 3
